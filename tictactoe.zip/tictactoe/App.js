import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
  O
      <View style={styles.row}>
        <View style={[styles.col1, styles.boxBottom, styles.boxRight]}>
        </View>
        O
        <View style={[styles.col2, styles.boxBottom, styles.boxRight]}>
        </View>
        <View style={[styles.col3, styles.boxBottom]}>
        </View>
        
      </View>

        <View style = {styles.row}>
          <View style= {[styles.col1, styles.boxRight]} />
          <View style= {[styles.col2, styles.boxRight]} />
          <View style= {styles.col3} />
        </View>

      <View style={styles.row}>
        <View style= {[styles.col1, styles.boxTop, styles.boxRight]} />
        <View style= {[styles.col1, styles.boxTop, styles.boxRight]} />
        <View style= {[styles.col3, styles.boxTop]} />
    </View>
  </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  row: {
    flexDirection: 'row',
    width: '80%',
    alignItems: 'center',
    justifyContent: 'center',
  },

  boxTop:{
    borderTopColor: 'black',
    borderTopWidth: 4,
  },
  boxBottom: {
    borderBottomColor: 'black',
    borderBottomWidth: 4,
  },
  boxRight: {
    borderRightColor: 'black',
    borderRightWidth: 4,
  },

  col1: {
    flex: 1,
    height:150,
  },
  col2: {
    flex: 1,
    height: 150,
  },
  col3: {
    flex: 1,
    height: 150,
  },
});
